import numpy as np
import torch

# Author: Elvis do A. Soares
# Github: @elvissoares
# Date: 2025-01-13
# Updated: 2025-01-13

" The Exponential Integrator for dynamical DFT"

class Dynamics():
    def __init__(self,dftclass,solver='ETD'):
        self.solvername = solver
        self.dftclass = dftclass

        if self.solvername == 'ETD':
            self.solver = ETD(self.dftclass)
        
    def Set_Solver_Parameters(self,dt=1e-4):
        self.dt = dt

        if self.solvername == 'ETD':
            self.solver.Set_Solver_Parameters(self.dt)

        self.setparametereq = False

    def Calculate_Dynamics(self,ti,tf,logoutput=False):

        if self.setparametereq: self.Set_Solver_Parameters()
        if self.solvername == 'ETD':
            self.solver.Calculate_TimeStep(ti,tf,logoutput)

# The class of ETD Algorithm
class ETD():
    def __init__(self,dftclass):
        self.dftclass = dftclass 

    def Set_Solver_Parameters(self,dt):
        self.h = dt*self.dftclass.sigma**2/self.dftclass.D # in scales of diffusion
        # The linear terms of PDE
        self.Loperator_k = torch.tensor(-self.dftclass.D*self.dftclass.Knorm**2,dtype=torch.float32,device=self.dftclass.device)
        self.Tlinear_k = torch.exp(self.h*self.Loperator_k) 
        # Defining the time marching operators arrays
        self.Tnon_k = self.dftclass.sigmaLancsoz*self.h*torch.where(self.Tlinear_k == 1.0,1.0,(self.Tlinear_k -1.0)/torch.log(self.Tlinear_k ))

        self.Noperator_k = torch.zeros_like(self.dftclass.rho_hat,device=self.dftclass.device)

        # self.dftclass.Vext[:] = self.dftclass.Vextfunc(0.0)
        self.dftclass.Vext_hat = self.dftclass.fft(self.dftclass.Vext)
            
        # calculate the nonlinear operator (with dealising)
        if self.dftclass.ndim == 1:
            self.Noperator_k[:] = -1.0j*self.dftclass.D*self.dftclass.K[0]*self.dftclass.fft(self.dftclass.rho*self.dftclass.ifft(1.0j*self.dftclass.K[0]*(self.dftclass.c1_hat-self.dftclass.beta*self.dftclass.Vext_hat)).real)
        elif self.dftclass.ndim == 2:
            self.Noperator_k[:] = -1.0j*self.dftclass.D*self.dftclass.K[0]*self.dftclass.fft(self.dftclass.rho*self.dftclass.ifft(1.0j*self.dftclass.K[0]*(self.dftclass.c1_hat-self.dftclass.beta*self.dftclass.Vext_hat)).real)
            self.Noperator_k[:] += -1.0j*self.dftclass.D*self.dftclass.K[1]*self.dftclass.fft(self.dftclass.rho*self.dftclass.ifft(1.0j*self.dftclass.K[1]*(self.dftclass.c1_hat-self.dftclass.beta*self.dftclass.Vext_hat)).real)
        else:
            self.Noperator_k[:] = -1.0j*self.dftclass.D*self.dftclass.K[0]*self.dftclass.fft(self.dftclass.rho*self.dftclass.ifft(1.0j*self.dftclass.K[0]*(self.dftclass.c1_hat-self.dftclass.beta*self.dftclass.Vext_hat)).real)
            self.Noperator_k[:] += -1.0j*self.dftclass.D*self.dftclass.K[1]*self.dftclass.fft(self.dftclass.rho*self.dftclass.ifft(1.0j*self.dftclass.K[1]*(self.dftclass.c1_hat-self.dftclass.beta*self.dftclass.Vext_hat)).real)
            self.Noperator_k[:] += -1.0j*self.dftclass.D*self.dftclass.K[2]*self.dftclass.fft(self.dftclass.rho*self.dftclass.ifft(1.0j*self.dftclass.K[2]*(self.dftclass.c1_hat-self.dftclass.beta*self.dftclass.Vext_hat)).real)

        self.dftclass.Calculate_FT()

        self.dftclass.rhodot[:] = self.dftclass.ifft(self.Loperator_k*self.dftclass.rho_hat+self.Noperator_k).real 

    def Calculate_TimeStep(self,ti,tf,logoutput=False):

        Nsteps = int((tf-ti)/self.h)
        
        t = ti

        self.dftclass.Calculate_FT()

        for i in range(Nsteps):
            self.dftclass.Calculate_weighted_densities()
            self.dftclass.Calculate_c1()
            # self.dftclass.Vext[:] = self.dftclass.Vextfunc(t)
            # self.dftclass.Vext_hat = self.dftclass.fft(self.dftclass.Vext)
            
            # calculate the nonlinear operator (with dealising)
            if self.dftclass.ndim == 1:
                self.Noperator_k[:] = -1.0j*self.dftclass.D*self.dftclass.K[0]*self.dftclass.fft(self.dftclass.rho*self.dftclass.ifft(1.0j*self.dftclass.K[0]*(self.dftclass.c1_hat-self.dftclass.beta*self.dftclass.Vext_hat)).real)
            elif self.dftclass.ndim == 2:
                self.Noperator_k[:] = -1.0j*self.dftclass.D*self.dftclass.K[0]*self.dftclass.fft(self.dftclass.rho*self.dftclass.ifft(1.0j*self.dftclass.K[0]*(self.dftclass.c1_hat-self.dftclass.beta*self.dftclass.Vext_hat)).real)
                self.Noperator_k[:] += -1.0j*self.dftclass.D*self.dftclass.K[1]*self.dftclass.fft(self.dftclass.rho*self.dftclass.ifft(1.0j*self.dftclass.K[1]*(self.dftclass.c1_hat-self.dftclass.beta*self.dftclass.Vext_hat)).real)
            else:
                self.Noperator_k[:] = -1.0j*self.dftclass.D*self.dftclass.K[0]*self.dftclass.fft(self.dftclass.rho*self.dftclass.ifft(1.0j*self.dftclass.K[0]*(self.dftclass.c1_hat-self.dftclass.beta*self.dftclass.Vext_hat)).real)
                self.Noperator_k[:] += -1.0j*self.dftclass.D*self.dftclass.K[1]*self.dftclass.fft(self.dftclass.rho*self.dftclass.ifft(1.0j*self.dftclass.K[1]*(self.dftclass.c1_hat-self.dftclass.beta*self.dftclass.Vext_hat)).real)
                self.Noperator_k[:] += -1.0j*self.dftclass.D*self.dftclass.K[2]*self.dftclass.fft(self.dftclass.rho*self.dftclass.ifft(1.0j*self.dftclass.K[2]*(self.dftclass.c1_hat-self.dftclass.beta*self.dftclass.Vext_hat)).real)

            # updating in time
            self.dftclass.rho_hat[:] = self.dftclass.rho_hat*self.Tlinear_k + self.Noperator_k*self.Tnon_k 

            # IFT to next step
            self.dftclass.rho[:] = self.dftclass.ifft(self.dftclass.rho_hat).real 
            self.dftclass.rho[self.dftclass.rho<1.0e-30] = 1.0e-30

            t += self.h

        self.dftclass.rhodot[:] = self.dftclass.ifft(self.Loperator_k*self.dftclass.rho_hat+self.Noperator_k).real 

        # Update Free-energy and so on
        self.dftclass.Update_System()

